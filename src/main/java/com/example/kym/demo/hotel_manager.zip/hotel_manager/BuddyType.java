package com.example.kym.demo.hotel_manager;

public enum BuddyType {

REGULAR,
ASSISTANT_DIRECTOR,
INSTRUCTOR

}
