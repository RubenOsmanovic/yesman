package com.example.kym.demo.hotel_manager;

public class User {
}
